import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  LayoutDashboard, 
  Activity, 
  Database, 
  Cpu, 
  Network, 
  AlertTriangle, 
  Search, 
  Filter,
  ChevronRight,
  Terminal,
  Layers,
  Zap,
  Globe,
  Settings,
  Share2,
  Maximize2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer
} from 'recharts';
import * as d3 from 'd3';
import { cn } from './lib/utils';
import { Microservice, ServiceStatus, DOMAINS, LANGUAGES, STATUS_COLORS } from './types';

// Mock data generator for 1000 services
const generateServices = (): Microservice[] => {
  const services: Microservice[] = [];
  for (let i = 0; i < 1000; i++) {
    const domain = DOMAINS[Math.floor(Math.random() * DOMAINS.length)];
    const language = LANGUAGES[Math.floor(Math.random() * LANGUAGES.length)];
    const statusRoll = Math.random();
    let status: ServiceStatus = 'healthy';
    if (statusRoll > 0.98) status = 'down';
    else if (statusRoll > 0.92) status = 'degraded';
    else if (statusRoll > 0.88) status = 'starting';

    services.push({
      id: `svc-${i.toString().padStart(4, '0')}`,
      name: `${domain.split(' ')[0]}-${language}-${i}`,
      domain,
      language,
      status,
      latency: Math.floor(Math.random() * 200) + 5,
      cpu: Math.floor(Math.random() * 80) + 5,
      memory: Math.floor(Math.random() * 1024) + 128,
      version: `v1.${Math.floor(Math.random() * 5)}.${Math.floor(Math.random() * 20)}`,
      dependencies: []
    });
  }

  // Generate random dependencies (sparse for 1000 nodes to keep it readable)
  services.forEach(svc => {
    const depCount = Math.floor(Math.random() * 3); // 0-2 deps
    for (let j = 0; j < depCount; j++) {
      const targetIdx = Math.floor(Math.random() * 1000);
      if (services[targetIdx].id !== svc.id) {
        svc.dependencies.push(services[targetIdx].id);
      }
    }
  });

  return services;
};

export default function App() {
  const [services, setServices] = useState<Microservice[]>([]);
  const [selectedDomain, setSelectedDomain] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [hoveredService, setHoveredService] = useState<Microservice | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'graph'>('grid');
  const [logs, setLogs] = useState<{id: string, msg: string, time: string, type: string}[]>([]);

  useEffect(() => {
    setServices(generateServices());
    
    // Simulate real-time updates
    const interval = setInterval(() => {
      setServices(prev => prev.map(s => {
        if (Math.random() > 0.95) {
          return {
            ...s,
            latency: Math.max(5, s.latency + (Math.random() * 20 - 10)),
            cpu: Math.min(100, Math.max(0, s.cpu + (Math.random() * 10 - 5)))
          };
        }
        return s;
      }));

      // Add random logs
      if (Math.random() > 0.7) {
        const randomSvc = Math.floor(Math.random() * 1000);
        const types = ['INFO', 'WARN', 'ERROR', 'DEBUG'];
        const type = types[Math.floor(Math.random() * types.length)];
        const newLog = {
          id: Math.random().toString(36).substr(2, 9),
          msg: `[svc-${randomSvc}] ${type}: Processing request in ${DOMAINS[Math.floor(Math.random() * DOMAINS.length)]}`,
          time: new Date().toLocaleTimeString(),
          type
        };
        setLogs(prev => [newLog, ...prev].slice(0, 20));
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const filteredServices = useMemo(() => {
    return services.filter(s => {
      const matchesDomain = !selectedDomain || s.domain === selectedDomain;
      const matchesSearch = s.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            s.id.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesDomain && matchesSearch;
    });
  }, [services, selectedDomain, searchQuery]);

  const stats = useMemo(() => {
    const total = services.length;
    const healthy = services.filter(s => s.status === 'healthy').length;
    const degraded = services.filter(s => s.status === 'degraded').length;
    const down = services.filter(s => s.status === 'down').length;
    
    const langDist = LANGUAGES.map(l => ({
      name: l,
      value: services.filter(s => s.language === l).length
    })).sort((a, b) => b.value - a.value);

    const domainDist = DOMAINS.map(d => ({
      name: d,
      value: services.filter(s => s.domain === d).length
    }));

    return { total, healthy, degraded, down, langDist, domainDist };
  }, [services]);

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-[#E4E4E7] font-sans selection:bg-emerald-500/30">
      {/* Header */}
      <header className="h-16 border-b border-white/5 bg-[#0D0D0F]/80 backdrop-blur-md flex items-center justify-between px-6 sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-emerald-500 rounded flex items-center justify-center shadow-[0_0_15px_rgba(16,185,129,0.3)]">
            <Layers className="w-5 h-5 text-black" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-tight uppercase">AgriMesh <span className="text-emerald-500">OS</span></h1>
            <p className="text-[10px] text-zinc-500 font-mono uppercase tracking-widest">Global Microservice Command</p>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="flex items-center gap-4 text-[11px] font-mono">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-zinc-400 uppercase">System:</span>
              <span className="text-emerald-500">NOMINAL</span>
            </div>
            <div className="flex items-center gap-2">
              <Activity className="w-3 h-3 text-zinc-500" />
              <span className="text-zinc-400 uppercase">Nodes:</span>
              <span>1,024</span>
            </div>
          </div>
          <div className="h-8 w-[1px] bg-white/5" />
          <button className="p-2 hover:bg-white/5 rounded-full transition-colors">
            <Settings className="w-4 h-4 text-zinc-400" />
          </button>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 border-r border-white/5 h-[calc(100vh-64px)] overflow-y-auto p-4 hidden lg:block sticky top-16">
          <div className="space-y-6">
            <div>
              <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-3 block">Navigation</label>
              <nav className="space-y-1">
                <button 
                  onClick={() => setSelectedDomain(null)}
                  className={cn(
                    "w-full flex items-center gap-3 px-3 py-2 rounded-md text-xs transition-all",
                    !selectedDomain ? "bg-emerald-500/10 text-emerald-500 border border-emerald-500/20" : "text-zinc-400 hover:bg-white/5"
                  )}
                >
                  <LayoutDashboard className="w-4 h-4" />
                  Global Overview
                </button>
              </nav>
            </div>

            <div>
              <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-3 block">Domains</label>
              <div className="space-y-1">
                {DOMAINS.map(domain => (
                  <button
                    key={domain}
                    onClick={() => setSelectedDomain(domain)}
                    className={cn(
                      "w-full flex items-center justify-between px-3 py-2 rounded-md text-xs transition-all group",
                      selectedDomain === domain ? "bg-white/10 text-white" : "text-zinc-400 hover:bg-white/5"
                    )}
                  >
                    <span className="truncate">{domain}</span>
                    <ChevronRight className={cn("w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity", selectedDomain === domain && "opacity-100")} />
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-6 border-t border-white/5">
              <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-3 block">System Health</label>
              <div className="space-y-3">
                <HealthBar label="Healthy" value={stats.healthy} total={stats.total} color="bg-emerald-500" />
                <HealthBar label="Degraded" value={stats.degraded} total={stats.total} color="bg-amber-500" />
                <HealthBar label="Down" value={stats.down} total={stats.total} color="bg-rose-500" />
              </div>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 overflow-x-hidden">
          {/* Top Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <StatCard icon={<Zap className="text-blue-400" />} label="Total Services" value={stats.total.toLocaleString()} sub="Active Mesh" />
            <StatCard icon={<Network className="text-emerald-400" />} label="Avg Latency" value="12ms" sub="-2% from last hour" />
            <StatCard icon={<Cpu className="text-purple-400" />} label="CPU Load" value="42%" sub="Across cluster" />
            <StatCard icon={<Database className="text-amber-400" />} label="Data Throughput" value="1.2 GB/s" sub="Real-time stream" />
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Service Grid Visualization */}
            <div className="xl:col-span-2 space-y-6">
              <div className="bg-[#0D0D0F] border border-white/5 rounded-xl p-6 shadow-2xl">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-sm font-bold uppercase tracking-tight">Service Mesh Topology</h2>
                    <p className="text-xs text-zinc-500">Real-time status of 1,000 polyglot microservices</p>
                  </div>
                  <div className="flex items-center gap-4">
                    {/* View Toggle */}
                    <div className="bg-white/5 p-1 rounded-lg flex items-center gap-1">
                      <button 
                        onClick={() => setViewMode('grid')}
                        className={cn(
                          "px-3 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider transition-all",
                          viewMode === 'grid' ? "bg-emerald-500 text-black" : "text-zinc-500 hover:text-zinc-300"
                        )}
                      >
                        Grid
                      </button>
                      <button 
                        onClick={() => setViewMode('graph')}
                        className={cn(
                          "px-3 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider transition-all",
                          viewMode === 'graph' ? "bg-emerald-500 text-black" : "text-zinc-500 hover:text-zinc-300"
                        )}
                      >
                        Graph
                      </button>
                    </div>

                    <div className="relative">
                      <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
                      <input 
                        type="text" 
                        placeholder="Filter services..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="bg-white/5 border border-white/10 rounded-full py-1.5 pl-9 pr-4 text-xs focus:outline-none focus:border-emerald-500/50 w-48 transition-all"
                      />
                    </div>
                  </div>
                </div>

                {/* The Viewport */}
                <div className="relative min-h-[400px] bg-black/20 rounded-lg border border-white/5 overflow-hidden">
                  {viewMode === 'grid' ? (
                    <div className="grid grid-cols-[repeat(auto-fill,minmax(12px,1fr))] gap-1.5 p-4">
                      {filteredServices.map((svc) => (
                        <motion.div
                          key={svc.id}
                          layoutId={svc.id}
                          onMouseEnter={() => setHoveredService(svc)}
                          onMouseLeave={() => setHoveredService(null)}
                          className={cn(
                            "w-3 h-3 rounded-[2px] cursor-crosshair transition-all duration-300 relative group",
                            STATUS_COLORS[svc.status],
                            svc.status === 'healthy' ? 'opacity-60 hover:opacity-100' : 'opacity-100 shadow-[0_0_8px_rgba(255,255,255,0.2)]'
                          )}
                        >
                          {svc.status === 'down' && (
                            <span className="absolute inset-0 animate-ping rounded-full bg-rose-500 opacity-75" />
                          )}
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <ServiceGraph 
                      services={filteredServices} 
                      onNodeClick={(svc) => setHoveredService(svc)} 
                    />
                  )}
                </div>

                {/* Legend */}
                <div className="mt-6 flex items-center gap-6 text-[10px] font-mono text-zinc-500 uppercase tracking-widest">
                  <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-emerald-500" /> Healthy</div>
                  <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-amber-500" /> Degraded</div>
                  <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-rose-500" /> Down</div>
                  <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full bg-blue-500" /> Starting</div>
                </div>
              </div>

              {/* Language Distribution Chart */}
              <div className="bg-[#0D0D0F] border border-white/5 rounded-xl p-6">
                <h2 className="text-sm font-bold uppercase tracking-tight mb-6">Polyglot Distribution</h2>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stats.langDist}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                      <XAxis 
                        dataKey="name" 
                        stroke="#71717a" 
                        fontSize={10} 
                        tickLine={false} 
                        axisLine={false}
                      />
                      <YAxis 
                        stroke="#71717a" 
                        fontSize={10} 
                        tickLine={false} 
                        axisLine={false}
                      />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#0D0D0F', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '12px' }}
                        itemStyle={{ color: '#10b981' }}
                      />
                      <Bar dataKey="value" fill="#10b981" radius={[4, 4, 0, 0]} barSize={30} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Sidebar Details & Logs */}
            <div className="space-y-6">
              {/* Service Inspector */}
              <div className="bg-[#0D0D0F] border border-white/5 rounded-xl p-6 min-h-[320px] relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-10">
                  <Globe className="w-32 h-32" />
                </div>
                
                <h2 className="text-sm font-bold uppercase tracking-tight mb-6 flex items-center gap-2">
                  <Search className="w-4 h-4 text-emerald-500" />
                  Service Inspector
                </h2>

                <AnimatePresence mode="wait">
                  {hoveredService ? (
                    <motion.div
                      key={hoveredService.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="space-y-4 relative z-10"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono text-zinc-500 uppercase">{hoveredService.id}</span>
                        <span className={cn("px-2 py-0.5 rounded-full text-[9px] font-bold uppercase", STATUS_COLORS[hoveredService.status], "text-black")}>
                          {hoveredService.status}
                        </span>
                      </div>
                      <h3 className="text-xl font-bold tracking-tight text-white">{hoveredService.name}</h3>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                          <p className="text-[10px] text-zinc-500 uppercase mb-1">Language</p>
                          <p className="text-sm font-bold text-emerald-400">{hoveredService.language}</p>
                        </div>
                        <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                          <p className="text-[10px] text-zinc-500 uppercase mb-1">Domain</p>
                          <p className="text-sm font-bold truncate">{hoveredService.domain}</p>
                        </div>
                        <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                          <p className="text-[10px] text-zinc-500 uppercase mb-1">Latency</p>
                          <p className="text-sm font-bold">{hoveredService.latency.toFixed(1)}ms</p>
                        </div>
                        <div className="bg-white/5 p-3 rounded-lg border border-white/5">
                          <p className="text-[10px] text-zinc-500 uppercase mb-1">CPU</p>
                          <p className="text-sm font-bold">{hoveredService.cpu}%</p>
                        </div>
                      </div>

                      <div className="pt-4 border-t border-white/5">
                        <p className="text-[10px] text-zinc-500 uppercase mb-2">Dependencies</p>
                        <div className="flex flex-wrap gap-2">
                          {hoveredService.dependencies.length > 0 ? (
                            hoveredService.dependencies.map(depId => (
                              <span key={depId} className="px-2 py-1 bg-white/5 rounded border border-white/10 text-[10px] font-mono">
                                {depId}
                              </span>
                            ))
                          ) : (
                            <span className="text-[10px] text-zinc-600 italic">No external dependencies</span>
                          )}
                        </div>
                      </div>

                      <div className="pt-4 border-t border-white/5">
                        <p className="text-[10px] text-zinc-500 uppercase mb-2">Deployment Info</p>
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-zinc-400">Version</span>
                          <span className="font-mono">{hoveredService.version}</span>
                        </div>
                        <div className="flex items-center justify-between text-xs mt-1">
                          <span className="text-zinc-400">Memory</span>
                          <span className="font-mono">{hoveredService.memory} MB</span>
                        </div>
                      </div>
                    </motion.div>
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-center py-12">
                      <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center mb-4">
                        <Activity className="w-6 h-6 text-zinc-600" />
                      </div>
                      <p className="text-xs text-zinc-500">
                        {viewMode === 'grid' ? 'Hover over a node' : 'Click a node'} in the mesh to inspect its telemetry
                      </p>
                    </div>
                  )}
                </AnimatePresence>
              </div>

              {/* Live Terminal Logs */}
              <div className="bg-[#0D0D0F] border border-white/5 rounded-xl p-6 flex flex-col h-[400px]">
                <h2 className="text-sm font-bold uppercase tracking-tight mb-4 flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-emerald-500" />
                  Mesh Event Log
                </h2>
                <div className="flex-1 bg-black/40 rounded-lg p-4 font-mono text-[10px] overflow-y-auto space-y-2 scrollbar-hide">
                  {logs.map(log => (
                    <div key={log.id} className="flex gap-3 border-b border-white/5 pb-1 last:border-0">
                      <span className="text-zinc-600 whitespace-nowrap">{log.time}</span>
                      <span className={cn(
                        "font-bold whitespace-nowrap",
                        log.type === 'ERROR' ? 'text-rose-500' : 
                        log.type === 'WARN' ? 'text-amber-500' : 
                        'text-emerald-500'
                      )}>
                        {log.type}
                      </span>
                      <span className="text-zinc-400 break-all">{log.msg}</span>
                    </div>
                  ))}
                  {logs.length === 0 && (
                    <div className="text-zinc-600 italic">Awaiting telemetry stream...</div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Footer Status Bar */}
      <footer className="h-8 border-t border-white/5 bg-[#0D0D0F] flex items-center justify-between px-6 text-[9px] font-mono text-zinc-500 uppercase tracking-[0.2em]">
        <div className="flex items-center gap-4">
          <span>Region: ASIA-SOUTHEAST-1</span>
          <span className="text-white/10">|</span>
          <span>Cluster: AGRI-PROD-01</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            Socket Connected
          </span>
          <span className="text-white/10">|</span>
          <span>Build: 2026.03.28.0839</span>
        </div>
      </footer>
    </div>
  );
}

function ServiceGraph({ services, onNodeClick }: { services: Microservice[], onNodeClick: (svc: Microservice) => void }) {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!svgRef.current || !containerRef.current || services.length === 0) return;

    const width = containerRef.current.clientWidth;
    const height = containerRef.current.clientHeight;

    // Clear previous
    d3.select(svgRef.current).selectAll("*").remove();

    const svg = d3.select(svgRef.current)
      .attr("width", width)
      .attr("height", height)
      .attr("viewBox", [0, 0, width, height])
      .attr("style", "max-width: 100%; height: auto;");

    const g = svg.append("g");

    // Zoom behavior
    const zoom = d3.zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.1, 8])
      .on("zoom", (event) => {
        g.attr("transform", event.transform);
      });

    svg.call(zoom);

    // Prepare data
    // For 1000 nodes, we limit the graph to a subset if it's too many, 
    // but D3 can handle 1000 nodes if we are careful.
    // We'll use a subset of nodes if services.length > 300 for better performance in preview
    const displayServices = services.length > 300 ? services.slice(0, 300) : services;
    const nodes = displayServices.map(d => ({ ...d }));
    const nodeIds = new Set(nodes.map(d => d.id));
    
    const links: any[] = [];
    nodes.forEach(source => {
      source.dependencies.forEach(targetId => {
        if (nodeIds.has(targetId)) {
          links.push({ source: source.id, target: targetId });
        }
      });
    });

    const simulation = d3.forceSimulation(nodes as any)
      .force("link", d3.forceLink(links).id((d: any) => d.id).distance(50))
      .force("charge", d3.forceManyBody().strength(-30))
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("x", d3.forceX(width / 2).strength(0.1))
      .force("y", d3.forceY(height / 2).strength(0.1));

    // Arrow marker
    svg.append("defs").append("marker")
      .attr("id", "arrowhead")
      .attr("viewBox", "-0 -5 10 10")
      .attr("refX", 15)
      .attr("refY", 0)
      .attr("orient", "auto")
      .attr("markerWidth", 6)
      .attr("markerHeight", 6)
      .attr("xoverflow", "visible")
      .append("svg:path")
      .attr("d", "M 0,-5 L 10 ,0 L 0,5")
      .attr("fill", "#ffffff20")
      .style("stroke", "none");

    const link = g.append("g")
      .attr("stroke", "#ffffff10")
      .attr("stroke-opacity", 0.6)
      .selectAll("line")
      .data(links)
      .join("line")
      .attr("stroke-width", 1)
      .attr("marker-end", "url(#arrowhead)");

    const node = g.append("g")
      .attr("stroke", "#fff")
      .attr("stroke-width", 0.5)
      .selectAll("circle")
      .data(nodes)
      .join("circle")
      .attr("r", 4)
      .attr("fill", (d: any) => {
        if (d.status === 'healthy') return '#10b981';
        if (d.status === 'degraded') return '#f59e0b';
        if (d.status === 'down') return '#f43f5e';
        return '#3b82f6';
      })
      .attr("cursor", "pointer")
      .on("click", (event, d: any) => {
        onNodeClick(d);
        // Highlight connections
        link.attr("stroke", (l: any) => (l.source.id === d.id || l.target.id === d.id) ? "#10b981" : "#ffffff10")
            .attr("stroke-width", (l: any) => (l.source.id === d.id || l.target.id === d.id) ? 2 : 1);
        node.attr("stroke-width", (n: any) => n.id === d.id ? 2 : 0.5)
            .attr("stroke", (n: any) => n.id === d.id ? "#fff" : "#fff");
      })
      .call(d3.drag<any, any>()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended));

    node.append("title")
      .text((d: any) => `${d.name} (${d.language})`);

    simulation.on("tick", () => {
      link
        .attr("x1", (d: any) => d.source.x)
        .attr("y1", (d: any) => d.source.y)
        .attr("x2", (d: any) => d.target.x)
        .attr("y2", (d: any) => d.target.y);

      node
        .attr("cx", (d: any) => d.x)
        .attr("cy", (d: any) => d.y);
    });

    function dragstarted(event: any) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      event.subject.fx = event.subject.x;
      event.subject.fy = event.subject.y;
    }

    function dragged(event: any) {
      event.subject.fx = event.x;
      event.subject.fy = event.y;
    }

    function dragended(event: any) {
      if (!event.active) simulation.alphaTarget(0);
      event.subject.fx = null;
      event.subject.fy = null;
    }

    // Initial zoom to fit
    svg.call(zoom.transform, d3.zoomIdentity.translate(width/2, height/2).scale(0.5).translate(-width/2, -height/2));

    return () => {
      simulation.stop();
    };
  }, [services, onNodeClick]);

  return (
    <div ref={containerRef} className="w-full h-full min-h-[400px]">
      <svg ref={svgRef} className="w-full h-full" />
      <div className="absolute bottom-4 right-4 flex flex-col gap-2">
        <div className="bg-black/60 backdrop-blur-md border border-white/10 p-2 rounded-lg text-[9px] text-zinc-400 font-mono">
          <p>SCROLL TO ZOOM</p>
          <p>DRAG TO PAN/MOVE</p>
          <p>CLICK TO INSPECT</p>
        </div>
        {services.length > 300 && (
          <div className="bg-amber-500/10 border border-amber-500/20 p-2 rounded-lg text-[9px] text-amber-500 font-mono max-w-[150px]">
            Showing 300/1000 nodes for performance
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, sub }: { icon: React.ReactNode, label: string, value: string, sub: string }) {
  return (
    <div className="bg-[#0D0D0F] border border-white/5 rounded-xl p-5 hover:border-white/10 transition-all group">
      <div className="flex items-center gap-3 mb-3">
        <div className="p-2 bg-white/5 rounded-lg group-hover:scale-110 transition-transform">
          {icon}
        </div>
        <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">{label}</span>
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-2xl font-bold tracking-tight text-white">{value}</span>
        <span className="text-[9px] text-zinc-600 font-mono">{sub}</span>
      </div>
    </div>
  );
}

function HealthBar({ label, value, total, color }: { label: string, value: number, total: number, color: string }) {
  const percentage = (value / total) * 100;
  return (
    <div className="space-y-1.5">
      <div className="flex justify-between text-[10px] font-mono">
        <span className="text-zinc-400 uppercase">{label}</span>
        <span className="text-zinc-500">{value}</span>
      </div>
      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          className={cn("h-full rounded-full", color)} 
        />
      </div>
    </div>
  );
}
