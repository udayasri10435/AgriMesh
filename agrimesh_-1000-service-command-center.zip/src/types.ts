export type ServiceStatus = 'healthy' | 'degraded' | 'down' | 'starting';

export interface Microservice {
  id: string;
  name: string;
  domain: string;
  language: string;
  status: ServiceStatus;
  latency: number; // ms
  cpu: number; // %
  memory: number; // MB
  version: string;
  dependencies: string[]; // IDs of services it depends on
}

export const DOMAINS = [
  'Crop Management',
  'Livestock',
  'Irrigation & Water',
  'Supply Chain',
  'Equipment & IoT',
  'Financial & Compliance',
  'User & Permissions',
  'Data & Analytics'
];

export const LANGUAGES = [
  'Go', 'Rust', 'Java', 'Python', 'TypeScript', 'C#', 'Elixir', 'C++', 'Scala', 'Ruby', 'Haskell', 'Zig'
];

export const STATUS_COLORS: Record<ServiceStatus, string> = {
  healthy: 'bg-emerald-500',
  degraded: 'bg-amber-500',
  down: 'bg-rose-500',
  starting: 'bg-blue-500'
};
